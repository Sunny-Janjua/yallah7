import mongoose from "mongoose";
import dotenv from 'dotenv';

dotenv.config({
    path: "./.env"
});

const mongoose_uri = process.env.MONGOOSE_URI || "mongodb://localhost:27017";

async function connectdb() {
    try {
        await mongoose.connect(mongoose_uri);
        console.log(`Mongoose Server Connected on ${mongoose_uri}`);
    } catch (error) {
        console.error("Mongoose Server is not Connected:", error.message);
    }
}

export default connectdb;
