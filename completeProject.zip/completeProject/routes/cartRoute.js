import express from 'express';
import cartController from '../controllers/cartController.js';
import {protect} from "../middlewares/authMiddleware.js"

const cartRouter = express.Router();

// Middleware to protect routes (ensure the user is authenticated)
cartRouter.use(protect);

// Get all items in the user's cart
cartRouter.get('/', cartController.getCartItems);

// Add an item to the user's cart
cartRouter.post('/add', cartController.addItemToCart);

// Remove an item from the user's cart by item ID
cartRouter.delete('/remove/:itemId', cartController.removeItemFromCart);

// Clear all items from the user's cart
cartRouter.delete('/clear', cartController.clearCart);

export default cartRouter;
