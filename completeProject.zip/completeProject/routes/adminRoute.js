import express from "express";
import adminController from "../controllers/adminController.js";
import { protect, authorizeRoles } from "../middlewares/authMiddleware.js";

const adminRouter = express.Router();

// Protect all admin routes and restrict access to admin users only
adminRouter.use(protect, authorizeRoles('admin'));

// Admin Routes
adminRouter.route("/users").get(adminController.getAllUsers); // Get all users
adminRouter.route("/sellers").get(adminController.getAllSellers); // Get all sellers
adminRouter
  .route("/categories")
  .post(adminController.createCategory)
  .get(adminController.getAllCategories); // Create and get categories
adminRouter
  .route("/categories/:categoryId")
  .put(adminController.updateCategory)
  .delete(adminController.deleteCategory); // Update and delete category
adminRouter
  .route("/subcategories")
  .post(adminController.createSubCategory)
  .get(adminController.getAllSubCategories); // Create and get subcategories
adminRouter
  .route("/subcategories/:subCategoryId")
  .put(adminController.updateSubCategory)
  .delete(adminController.deleteSubCategory); // Update and delete subcategory

export default adminRouter;
