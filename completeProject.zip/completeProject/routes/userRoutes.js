// routes/userRoute.js
import express from "express";
import { getUserProfile } from "../controllers/userController.js";
import { updateUserProfile } from "../controllers/userController.js";
import { deleteUserAccount } from "../controllers/userController.js";
import { protect } from "../middlewares/authMiddleware.js"

const userRouter = express.Router();

// Protect the routes to ensure only authenticated users can access them
userRouter.route("/profile")
  .get(protect, getUserProfile)  // Get user profile
  .put(protect, updateUserProfile) // Update user profile

  userRouter.route("/delete")
  .delete(protect, deleteUserAccount); // Delete user account

export default userRouter;
