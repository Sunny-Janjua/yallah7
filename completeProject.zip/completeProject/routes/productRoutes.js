import express from 'express';
import productController from '../controllers/productController.js';
import { protect } from "../middlewares/authMiddleware.js"

const productRouter = express.Router();

// Middleware to protect routes (ensure the user is authenticated)
productRouter.use(protect);

// Create a new product
productRouter.post('/', productController.createProduct);

// Get all products
productRouter.get('/', productController.getAllProducts);

// Get single product by ID
productRouter.get('/:productId', productController.getProductById);

// Update product
productRouter.put('/:productId', productController.updateProduct);

// Delete product
productRouter.delete('/:productId', productController.deleteProduct);

export default productRouter;
