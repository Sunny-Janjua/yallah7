import express from 'express';
import authController from '../controllers/authController.js';

const authRouter = express.Router();

// User Registration
authRouter.post('/register/user', authController.registerUser);

// Admin Registration
authRouter.post('/register/admin', authController.registerAdmin);

// Verify OTP
authRouter.post('/verify-otp', authController.verifyOTP);

// User Login
authRouter.post('/login', authController.loginUser);

// Admin Login
authRouter.post('/login/admin', authController.loginAdmin);

export default authRouter;
