// routes/sellerRoutes.js

import express from "express";
import sellerController from "../controllers/sellerController.js";
import { protect, authorizeRoles } from "../middlewares/authMiddleware.js";

const router = express.Router();

// Register a new seller - No authentication required
router.post("/register", sellerController.registerSeller);

// Protect all subsequent routes and authorize only sellers
router.use(protect, authorizeRoles("seller"));

// Get details of a specific seller
router.get("/:sellerId", sellerController.getSellerDetails);

// Update seller profile
router.put("/:sellerId/update", sellerController.updateSellerProfile);

// Add a product to the seller's store
router.post("/add-product", sellerController.addSellerProduct);

// Handle wallet transactions
router.post("/transaction", sellerController.handleSellerTransaction);

export default router;
