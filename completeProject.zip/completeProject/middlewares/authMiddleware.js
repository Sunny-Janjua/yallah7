// middlewares/authMiddleware.js

import jwt from "jsonwebtoken";
import User from "../models/userModel.js";
import Seller from "../models/sellerModel.js";
import Admin from "../models/adminModel.js";
import dotenv from "dotenv";

dotenv.config({ path: "./.env" });

/**
 * Middleware to protect routes by verifying JWT token
 */
export const protect = async (req, res, next) => {
  let token;

  // Check if token is present in the Authorization header
  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    try {
      // Extract the token from the Authorization header
      token = req.headers.authorization.split(" ")[1];

      // Verify the token using the secret key
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Find the user based on the role decoded from the token
      let user;
      switch (decoded.role) {
        case "user":
          user = await User.findById(decoded.id).select("-password");
          break;
        case "seller":
          user = await Seller.findById(decoded.id).populate("user").select("-password");
          break;
        case "admin":
          user = await Admin.findById(decoded.id).select("-password");
          break;
        default:
          return res.status(401).json({ message: "Not authorized, role not recognized." });
      }

      // If user not found, return unauthorized error
      if (!user) {
        return res.status(401).json({ message: "Not authorized, user not found." });
      }

      // Attach the user object to the request object
      req.user = user;
      next(); // Move to the next middleware or route handler
    } catch (error) {
      console.error("❌ Authentication Middleware Error:", error);
      return res.status(401).json({ message: "Not authorized, token failed.", error: error.message });
    }
  } else {
    return res.status(401).json({ message: "Not authorized, no token provided." });
  }
};

/**
 * Middleware to authorize roles for accessing specific routes
 */
export const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated." });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: `User role '${req.user.role}' is not authorized to access this route.` });
    }

    next(); // Move to the next middleware or route handler
  };
};

/**
 * Middleware to handle errors in the application
 */
export const errorHandler = (err, req, res, next) => {
  console.error("Error Handler:", err.stack);
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode).json({
    message: err.message,
    stack: process.env.NODE_ENV === "production" ? "🥞" : err.stack,
  });
};
