// controllers/payment/paymentController.js
import Wallet from "../models/walletModel.js";
import Order from "../models/orderModel.js";

// Process a payment for an order
export const processPayment = async (req, res) => {
  const userId = req.user.id;
  const { orderId, paymentMethod } = req.body; // paymentMethod could be 'credit_card', 'paypal', etc.

  try {
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ message: "Order not found." });
    }

    if (order.paymentStatus === "paid") {
      return res.status(400).json({ message: "Order is already paid." });
    }

    // Process payment using a payment gateway utility
    const paymentResult = await processPaymentGateway(order.totalAmount, paymentMethod);
    if (!paymentResult.success) {
      return res.status(400).json({ message: "Payment failed.", details: paymentResult.message });
    }

    // Update order payment status
    order.paymentStatus = "paid";
    order.status = "confirmed"; // Optionally update status
    await order.save();

    // Credit user's wallet
    const userWallet = await Wallet.findOne({ userId });
    if (!userWallet) {
      return res.status(404).json({ message: "User wallet not found." });
    }

    userWallet.balance += order.totalAmount; // Assume totalAmount is the payment amount
    userWallet.transactions.push({
      type: "credit",
      amount: order.totalAmount,
      description: `Payment for Order ID: ${order._id}`,
    });
    userWallet.lastUpdated = Date.now();
    await userWallet.save();

    res.status(200).json({ message: "Payment successful.", order });
  } catch (error) {
    console.error("Error in processPayment:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Handle payment gateway webhook/callback
export const paymentWebhook = async (req, res) => {
  try {
    const event = req.body;

    // Verify the event's authenticity here (e.g., using Stripe's signing secret)

    switch (event.type) {
      case "payment_intent.succeeded":
        const paymentIntent = event.data.object;
        // Handle successful payment intent
        break;
      // Handle other event types as needed
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    res.status(200).json({ received: true });
  } catch (error) {
    console.error("Error in paymentWebhook:", error);
    res.status(500).json({ message: "Webhook error" });
  }
};

// Get wallet balance for authenticated user
export const getWalletBalance = async (req, res) => {
  const userId = req.user.id;

  try {
    const wallet = await Wallet.findOne({ userId });
    if (!wallet) {
      return res.status(404).json({ message: "Wallet not found." });
    }

    res.status(200).json({ balance: wallet.balance, transactions: wallet.transactions });
  } catch (error) {
    console.error("Error in getWalletBalance:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Credit user's wallet (e.g., adding funds)
export const creditWallet = async (req, res) => {
  const userId = req.user.id;
  const { amount, description } = req.body;

  if (amount <= 0) {
    return res.status(400).json({ message: "Amount must be greater than zero." });
  }

  try {
    const wallet = await Wallet.findOne({ userId });
    if (!wallet) {
      return res.status(404).json({ message: "Wallet not found." });
    }

    wallet.balance += amount;
    wallet.transactions.push({
      type: "credit",
      amount,
      description,
    });
    wallet.lastUpdated = Date.now();
    await wallet.save();

    res.status(200).json({ message: "Wallet credited successfully.", balance: wallet.balance });
  } catch (error) {
    console.error("Error in creditWallet:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Debit user's wallet (e.g., deducting funds)
export const debitWallet = async (req, res) => {
  const userId = req.user.id;
  const { amount, description } = req.body;

  if (amount <= 0) {
    return res.status(400).json({ message: "Amount must be greater than zero." });
  }

  try {
    const wallet = await Wallet.findOne({ userId });
    if (!wallet) {
      return res.status(404).json({ message: "Wallet not found." });
    }

    if (wallet.balance < amount) {
      return res.status(400).json({ message: "Insufficient balance." });
    }

    wallet.balance -= amount;
    wallet.transactions.push({
      type: "debit",
      amount,
      description,
    });
    wallet.lastUpdated = Date.now();
    await wallet.save();

    res.status(200).json({ message: "Wallet debited successfully.", balance: wallet.balance });
  } catch (error) {
    console.error("Error in debitWallet:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Export payment controller functions
export default {
  processPayment,
  paymentWebhook,
  getWalletBalance,
  creditWallet,
  debitWallet,
};
