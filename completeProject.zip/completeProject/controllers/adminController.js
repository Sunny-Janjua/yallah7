// controllers/admin/adminController.js
import Admin from "../models/adminModel.js";
import User from "../models/userModel.js";
import Seller from "../models/sellerModel.js";
import Category from "../models/categoryModel.js";
import SubCategory from "../models/subcaragoryModel.js";

// Get All Users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password -otp -otpExpires");
    res.status(200).json({ users });
    console.log('Admin: Retrieved all users');
  } catch (error) {
    console.error("Error in getAllUsers:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Get All Sellers
const getAllSellers = async (req, res) => {
  try {
    const sellers = await Seller.find().populate("userId", "username email").populate("wallet", "balance");
    res.status(200).json({ sellers });
    console.log('Admin: Retrieved all sellers');
  } catch (error) {
    console.error("Error in getAllSellers:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Create a Category
const createCategory = async (req, res) => {
  const { name, description } = req.body;

  try {
    const existingCategory = await Category.findOne({ name });
    if (existingCategory) {
      return res.status(409).json({ message: "Category already exists." });
    }

    const category = new Category({ name, description });
    await category.save();
    res.status(201).json({ message: "Category created successfully.", category });
    console.log(`Admin: Created category '${name}'`);
  } catch (error) {
    console.error("Error in createCategory:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Get All Categories
const getAllCategories = async (req, res) => {
  try {
    const categories = await Category.find().populate("subCategories");
    res.status(200).json({ categories });
    console.log('Admin: Retrieved all categories');
  } catch (error) {
    console.error("Error in getAllCategories:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Update a Category
const updateCategory = async (req, res) => {
  const { categoryId } = req.params;
  const { name, description } = req.body;

  try {
    const category = await Category.findById(categoryId);
    if (!category) {
      return res.status(404).json({ message: "Category not found." });
    }

    if (name) category.name = name;
    if (description) category.description = description;

    await category.save();
    res.status(200).json({ message: "Category updated successfully.", category });
    console.log(`Admin: Updated category ID ${categoryId}`);
  } catch (error) {
    console.error("Error in updateCategory:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Delete a Category
const deleteCategory = async (req, res) => {
  const { categoryId } = req.params;

  try {
    const category = await Category.findById(categoryId);
    if (!category) {
      return res.status(404).json({ message: "Category not found." });
    }
    await category.remove();
    res.status(200).json({ message: "Category deleted successfully." });
    console.log(`Admin: Deleted category ID ${categoryId}`);
  } catch (error) {
    console.error("Error in deleteCategory:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Create a SubCategory
const createSubCategory = async (req, res) => {
  const { name, description, parentCategoryId } = req.body;

  try {
    const existingSubCategory = await SubCategory.findOne({ name });
    if (existingSubCategory) {
      return res.status(409).json({ message: "SubCategory already exists." });
    }

    const subCategory = new SubCategory({ name, description });
    await subCategory.save();

    // Associate subcategory with parent category
    if (parentCategoryId) {
      const parentCategory = await Category.findById(parentCategoryId);
      if (parentCategory) {
        parentCategory.subCategories.push(subCategory._id);
        await parentCategory.save();
        console.log(`Admin: Associated subCategory ID ${subCategory._id} with category ID ${parentCategoryId}`);
      }
    }

    res.status(201).json({ message: "SubCategory created successfully.", subCategory });
    console.log(`Admin: Created subCategory '${name}'`);
  } catch (error) {
    console.error("Error in createSubCategory:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Get All SubCategories
const getAllSubCategories = async (req, res) => {
  try {
    const subCategories = await SubCategory.find().populate("parent");
    res.status(200).json({ subCategories });
    console.log('Admin: Retrieved all subCategories');
  } catch (error) {
    console.error("Error in getAllSubCategories:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Update a SubCategory
const updateSubCategory = async (req, res) => {
  const { subCategoryId } = req.params;
  const { name, description, parentCategoryId } = req.body;

  try {
    const subCategory = await SubCategory.findById(subCategoryId);
    if (!subCategory) {
      return res.status(404).json({ message: "SubCategory not found." });
    }

    if (name) subCategory.name = name;
    if (description) subCategory.description = description;

    await subCategory.save();

    // Update parent category association if provided
    if (parentCategoryId) {
      const parentCategory = await Category.findById(parentCategoryId);
      if (parentCategory) {
        if (!parentCategory.subCategories.includes(subCategory._id)) {
          parentCategory.subCategories.push(subCategory._id);
          await parentCategory.save();
          console.log(`Admin: Associated subCategory ID ${subCategoryId} with category ID ${parentCategoryId}`);
        }
      }
    }

    res.status(200).json({ message: "SubCategory updated successfully.", subCategory });
    console.log(`Admin: Updated subCategory ID ${subCategoryId}`);
  } catch (error) {
    console.error("Error in updateSubCategory:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Delete a SubCategory
const deleteSubCategory = async (req, res) => {
  const { subCategoryId } = req.params;

  try {
    const subCategory = await SubCategory.findById(subCategoryId);
    if (!subCategory) {
      return res.status(404).json({ message: "SubCategory not found." });
    }

    // Remove subCategory from its parent category
    const parentCategory = await Category.findOne({ subCategories: subCategoryId });
    if (parentCategory) {
      parentCategory.subCategories.pull(subCategoryId);
      await parentCategory.save();
      console.log(`Admin: Removed subCategory ID ${subCategoryId} from category ID ${parentCategory._id}`);
    }

    await subCategory.remove();
    res.status(200).json({ message: "SubCategory deleted successfully." });
    console.log(`Admin: Deleted subCategory ID ${subCategoryId}`);
  } catch (error) {
    console.error("Error in deleteSubCategory:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Exporting all functions as an object
export default {
  getAllUsers,
  getAllSellers,
  createCategory,
  getAllCategories,
  updateCategory,
  deleteCategory,
  createSubCategory,
  getAllSubCategories,
  updateSubCategory,
  deleteSubCategory,
};
