// controllers/order/orderController.js
import Order from "../models/orderModel.js";
import Product from "../models/productModel.js";
import User from "../models/userModel.js";
import Seller from "../models/sellerModel.js";

// Create a new order
const createOrder = async (req, res) => {
  const { items, shippingAddress, billingAddress } = req.body;

  try {
    if (!items || items.length === 0) {
      return res.status(400).json({ message: "No items provided for the order." });
    }

    // Validate each item
    let totalAmount = 0;
    let vendorId = null;

    for (const item of items) {
      const product = await Product.findById(item.product).populate("seller");
      if (!product) {
        return res.status(404).json({ message: `Product with ID ${item.product} not found.` });
      }

      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `Insufficient stock for product ${product.name}.` });
      }

      // Ensure all products are from the same vendor
      if (vendorId && product.vendor.toString() !== vendorId) {
        return res.status(400).json({ message: "All products in the order must be from the same vendor." });
      }
      vendorId = product.vendor.toString();

      totalAmount += product.price * item.quantity;
    }

    // Create the order
    const order = new Order({
      user: req.user.id,
      items,
      totalAmount,
      shippingAddress,
      billingAddress,
      vendor: vendorId,
      status: "pending",
      paymentStatus: "pending",
    });

    await order.save();

    // Decrement product stock
    for (const item of items) {
      await Product.findByIdAndUpdate(item.product, { $inc: { stock: -item.quantity } });
    }

    res.status(201).json({ message: "Order placed successfully.", order });
    console.log(`Create Order: Order ID ${order._id} created by User ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in createOrder:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Get Order By ID
const getOrderById = async (req, res) => {
  const { orderId } = req.params;

  try {
    const order = await Order.findById(orderId)
      .populate("user", "username email")
      .populate("vendor", "username email")
      .populate("items.product", "name price description");

    if (!order) {
      return res.status(404).json({ message: "Order not found." });
    }

    // Authorization: Only the user who placed the order, the vendor, or an admin can view the order
    if (
      order.user._id.toString() !== req.user.id &&
      order.vendor._id.toString() !== req.user.id &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not authorized to view this order." });
    }

    res.status(200).json({ order });
    console.log(`Get Order By ID: Retrieved Order ID ${orderId}`);
  } catch (error) {
    console.error("Error in getOrderById:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Get Orders for a User
const getUserOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user.id })
      .populate("vendor", "username email")
      .populate("items.product", "name price description")
      .sort({ createdAt: -1 });

    res.status(200).json({ orders });
    console.log(`Get User Orders: Retrieved orders for User ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in getUserOrders:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Get Orders for a Seller
const getSellerOrders = async (req, res) => {
  try {
    const seller = await Seller.findOne({ userId: req.user.id });
    if (!seller) {
      return res.status(404).json({ message: "Seller profile not found." });
    }

    const orders = await Order.find({ vendor: seller.userId })
      .populate("user", "username email")
      .populate("items.product", "name price description")
      .sort({ createdAt: -1 });

    res.status(200).json({ orders });
    console.log(`Get Seller Orders: Retrieved orders for Seller ID ${seller.userId}`);
  } catch (error) {
    console.error("Error in getSellerOrders:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Update Order Status
const updateOrderStatus = async (req, res) => {
  const { orderId } = req.params;
  const { status } = req.body;

  const validStatuses = ["pending", "confirmed", "shipped", "delivered", "cancelled"];

  if (!validStatuses.includes(status)) {
    return res.status(400).json({ message: "Invalid status value." });
  }

  try {
    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({ message: "Order not found." });
    }

    // Authorization: Only the vendor, admin, or the user can update the order status
    if (
      order.vendor.toString() !== req.user.id &&
      req.user.role !== "admin" &&
      order.user.toString() !== req.user.id
    ) {
      return res.status(403).json({ message: "Not authorized to update this order." });
    }

    // Implement business rules for status transitions
    const currentStatus = order.status;
    const allowedTransitions = {
      pending: ["confirmed", "cancelled"],
      confirmed: ["shipped", "cancelled"],
      shipped: ["delivered"],
      delivered: [],
      cancelled: [],
    };

    if (!allowedTransitions[currentStatus].includes(status)) {
      return res.status(400).json({ message: `Cannot change status from ${currentStatus} to ${status}.` });
    }

    order.status = status;
    await order.save();

    res.status(200).json({ message: "Order status updated successfully.", order });
    console.log(`Update Order Status: Order ID ${orderId} status updated to ${status}`);
  } catch (error) {
    console.error("Error in updateOrderStatus:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Cancel Order
const cancelOrder = async (req, res) => {
  const { orderId } = req.params;

  try {
    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({ message: "Order not found." });
    }

    // Only the user who placed the order can cancel it if it's still pending or confirmed
    if (order.user.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to cancel this order." });
    }

    if (!["pending", "confirmed"].includes(order.status)) {
      return res.status(400).json({ message: `Cannot cancel an order with status ${order.status}.` });
    }

    order.status = "cancelled";
    await order.save();

    // Restore product stock
    for (const item of order.items) {
      await Product.findByIdAndUpdate(item.product, { $inc: { stock: item.quantity } });
    }

    res.status(200).json({ message: "Order cancelled successfully.", order });
    console.log(`Cancel Order: Order ID ${orderId} cancelled by User ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in cancelOrder:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Export all functions as default
export default {
  createOrder,
  getOrderById,
  getUserOrders,
  getSellerOrders,
  updateOrderStatus,
  cancelOrder,
};
