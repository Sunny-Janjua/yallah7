// controllers/product/productController.js
import Product from "../models/productModel.js";
import Category from "../models/categoryModel.js";
import Seller from "../models/sellerModel.js";
import { uploadOnCloudinary } from "../utils/cloudinary.js";

/**
 * Create a new product
 */
export const createProduct = async (req, res, next) => {
  const { name, description, price, stock, category, variations } = req.body;

  try {
    // Validate required fields
    if (!name || !description || !price || !stock || !category) {
      return res.status(400).json({ message: "All required fields must be provided." });
    }

    // Check if category exists
    const categoryExists = await Category.findById(category);
    if (!categoryExists) {
      return res.status(404).json({ message: "Category not found." });
    }

    // Handle image uploads
    let imageUrls = [];
    if (req.files && req.files.length > 0) {
      const uploadPromises = req.files.map((file) => uploadOnCloudinary(file.path));
      const uploadResponses = await Promise.all(uploadPromises);
      imageUrls = uploadResponses
        .filter((response) => response) // Filter out failed uploads
        .map((response) => response.secure_url);
    }

    // Create new product
    const product = new Product({
      name,
      description,
      price,
      stock,
      category,
      images: imageUrls,
      seller: req.user.id, // Assuming the authenticated user is the seller
      variations: variations ? JSON.parse(variations) : [], // Handle variations
    });

    await product.save();
    console.log("Create Product: Product saved successfully:", product);

    // Add product to seller's list
    await Seller.findByIdAndUpdate(req.user.sellerId, { $push: { products: product._id } });
    console.log(`Create Product: Product added to seller ID ${req.user.sellerId}`);

    res.status(201).json({ message: "Product created successfully.", product });
  } catch (error) {
    console.error("Error in createProduct:", error);
    next(error); // Pass the error to the errorHandler middleware
  }
};

/**
 * Get all products
 */
export const getAllProducts = async (req, res, next) => {
  try {
    const products = await Product.find()
      .populate("category", "name")
      .populate("seller", "storeName")
      .populate("vendor", "username email"); // Remove if vendor is not needed

    res.status(200).json({ products });
    console.log("Get All Products: Retrieved all products");
  } catch (error) {
    console.error("Error in getAllProducts:", error);
    next(error); // Pass the error to the errorHandler middleware
  }
};

/**
 * Get single product by ID
 */
export const getProductById = async (req, res, next) => {
  const { productId } = req.params;

  try {
    const product = await Product.findById(productId)
      .populate("category", "name")
      .populate("seller", "storeName")
      .populate("vendor", "username email"); // Remove if vendor is not needed

    if (!product) {
      return res.status(404).json({ message: "Product not found." });
    }

    res.status(200).json({ product });
    console.log(`Get Product By ID: Retrieved product ID ${productId}`);
  } catch (error) {
    console.error("Error in getProductById:", error);
    next(error); // Pass the error to the errorHandler middleware
  }
};

/**
 * Update product
 */
export const updateProduct = async (req, res, next) => {
  const { productId } = req.params;
  const updates = req.body;

  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: "Product not found." });
    }

    // Ensure that the authenticated user is the seller or an admin
    if (product.seller.toString() !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized to update this product." });
    }

    // If updating category, validate it
    if (updates.category) {
      const categoryExists = await Category.findById(updates.category);
      if (!categoryExists) {
        return res.status(404).json({ message: "Category not found." });
      }
    }

    // If updating images
    if (req.files && req.files.length > 0) {
      const uploadPromises = req.files.map((file) => uploadOnCloudinary(file.path));
      const uploadResponses = await Promise.all(uploadPromises);
      const imageUrls = uploadResponses
        .filter((response) => response)
        .map((response) => response.secure_url);
      updates.images = imageUrls;
    }

    // If updating variations, parse JSON
    if (updates.variations) {
      updates.variations = JSON.parse(updates.variations);
    }

    const updatedProduct = await Product.findByIdAndUpdate(productId, updates, { new: true })
      .populate("category", "name")
      .populate("seller", "storeName")
      .populate("vendor", "username email"); // Remove if vendor is not needed

    res.status(200).json({ message: "Product updated successfully.", product: updatedProduct });
    console.log(`Update Product: Updated product ID ${productId}`);
  } catch (error) {
    console.error("Error in updateProduct:", error);
    next(error); // Pass the error to the errorHandler middleware
  }
};

/**
 * Delete product
 */
export const deleteProduct = async (req, res, next) => {
  const { productId } = req.params;

  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: "Product not found." });
    }

    // Ensure that the authenticated user is the seller or an admin
    if (product.seller.toString() !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized to delete this product." });
    }

    await product.remove();
    console.log(`Delete Product: Deleted product ID ${productId}`);

    // Remove product from seller's list
    await Seller.findByIdAndUpdate(product.seller, { $pull: { products: product._id } });
    console.log(`Delete Product: Removed product ID ${productId} from seller ID ${product.seller}`);

    res.status(200).json({ message: "Product deleted successfully." });
  } catch (error) {
    console.error("Error in deleteProduct:", error);
    next(error); // Pass the error to the errorHandler middleware
  }
};

export default {
  createProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct
};
