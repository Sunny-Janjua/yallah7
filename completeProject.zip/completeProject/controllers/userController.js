// controllers/user/userController.js
import User from "../models/userModel.js";
import bcrypt from "bcryptjs";
import Seller from "../models/sellerModel.js"; // Import Seller model for cleanup

// Get User Profile
export const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password -otp -otpExpires");
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }
    res.status(200).json({ user });
    console.log(`Get User Profile: Retrieved profile for user ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in getUserProfile:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Update User Profile
export const updateUserProfile = async (req, res) => {
  const { username, email, password } = req.body;

  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // Update fields if provided
    if (username) user.username = username;
    if (email) user.email = email;

    if (password) {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);
    }

    await user.save();
    res.status(200).json({
      message: "Profile updated successfully.",
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
      },
    });
    console.log(`Update User Profile: Updated profile for user ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in updateUserProfile:", error);
    res.status(500).json({ message: "Server error." });
  }
};

// Delete User Account
export const deleteUserAccount = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // If the user is a seller, handle additional cleanup
    if (user.role === "seller" && user.sellerId) {
      await Seller.findByIdAndDelete(user.sellerId); // Delete seller document
      console.log(`Delete User Account: Deleted seller account for user ID ${req.user.id}`);
      // Implement any additional cleanup as necessary, e.g., removing products, wallets, etc.
    }

    await user.remove();
    res.status(200).json({ message: "User account deleted successfully." });
    console.log(`Delete User Account: Deleted account for user ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in deleteUserAccount:", error);
    res.status(500).json({ message: "Server error." });
  }
};

export default {
  getUserProfile,
  updateUserProfile,
  deleteUserAccount
};
