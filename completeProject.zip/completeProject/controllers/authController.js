// controllers/authController.js
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import User from '../models/userModel.js';
import Seller from '../models/sellerModel.js';
import Admin from '../models/adminModel.js';
import sendEmail from '../utils/emailService.js';
import generateOTP from '../utils/otpGenerator.js';
import validateOTP from '../utils/otpValidaiton.js';
import dotenv from 'dotenv';

dotenv.config({ path: './.env' });

// Function to generate JWT token
const generateToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: '7d' });
};

/**
 * Register a new user
 */
const registerUser = async (req, res) => {
  const { username, email, password } = req.body;
  try {
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      console.log('Register User: User already exists with email:', email);
      return res.status(400).json({ message: 'User already exists with this email.' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Generate OTP
    const otp = generateOTP();
    const otpExpires = Date.now() + 10 * 60 * 1000; // 10 minutes

    // Create user
    const user = new User({
      username,
      email,
      password: hashedPassword,
      role: 'user',
      otp,
      otpExpires,
    });
    await user.save();
    console.log('Register User: User saved successfully:', user);

    // Send OTP email
    await sendEmail({
      to: email,
      subject: 'Your OTP Code',
      text: `Your OTP code is ${otp}`,
      html: `<p>Your OTP code is <b>${otp}</b></p>`,
    });
    console.log('Register User: OTP sent to email');

    res.status(201).json({ message: 'Registration successful. Please verify your email with the OTP sent.' });
  } catch (error) {
    console.error('Error in registerUser:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

/**
 * Register a new admin
 */
const registerAdmin = async (req, res) => {
  const { username, email, password } = req.body;
  console.log('Register Admin: Received request with data:', req.body);

  try {
    // Check if admin exists
    const existingAdmin = await Admin.findOne({ email });
    if (existingAdmin) {
      console.log('Register Admin: Admin already exists with email:', email);
      return res.status(400).json({ message: 'Admin already exists with this email.' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Generate OTP
    const otp = generateOTP();
    const otpExpires = Date.now() + 10 * 60 * 1000; // 10 minutes

    // Create admin
    const admin = new Admin({
      username,
      email,
      password: hashedPassword,
      role: 'admin',
      otp,
      otpExpires,
    });
    await admin.save();
    console.log('Register Admin: Admin saved successfully:', admin);

    // Send OTP email
    await sendEmail({
      to: email,
      subject: 'Your OTP Code',
      text: `Your OTP code is ${otp}`,
      html: `<p>Your OTP code is <b>${otp}</b></p>`,
    });
    console.log('Register Admin: OTP sent to email');

    res.status(201).json({ message: 'Registration successful. Please verify your email with the OTP sent.' });
  } catch (error) {
    console.error('Error in registerAdmin:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

/**
 * Verify OTP after registration
 */
const verifyOTP = async (req, res) => {
  const { email, otp } = req.body;

  try {
    let user = await User.findOne({ email });
    let role = 'user';
    if (!user) {
      user = await Seller.findOne({ email });
      role = 'seller'; // Changed from 'vendor' to 'seller' for consistency
    }
    if (!user) {
      user = await Admin.findOne({ email });
      role = 'admin';
    }

    if (!user) {
      return res.status(400).json({ message: 'User not found.' });
    }

    if (user.isVerified) {
      return res.status(400).json({ message: 'User already verified.' });
    }

    const isValid = validateOTP(user, otp);
    if (!isValid) {
      return res.status(400).json({ message: 'Invalid or expired OTP.' });
    }

    user.isVerified = true;
    user.otp = undefined;
    user.otpExpires = undefined;
    await user.save();

    const token = generateToken(user._id, user.role);
    console.log(`Verify OTP: JWT Token for ${email}: ${token}`); // Log the JWT token
    res.status(200).json({ message: 'Verification successful.', token });
    console.log(`Verify OTP: User ${email} verified successfully.`);
  } catch (error) {
    console.error('Error in verifyOTP:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

/**
 * Login for Users
 */
const loginUser = async (req, res) => {
  const { email, password } = req.body;
  console.log('Login User: Received request with data:', req.body);

  try {
    const user = await User.findOne({ email });
    if (!user) {
      console.log('Login User: Invalid credentials for email:', email);
      return res.status(400).json({ message: 'Invalid credentials.' });
    }

    if (!user.isVerified) {
      return res.status(400).json({ message: 'Please verify your email before logging in.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.log('Login User: Invalid password for email:', email);
      return res.status(400).json({ message: 'Invalid credentials.' });
    }

    const token = generateToken(user._id, user.role);
    console.log(`Login User: JWT Token for ${email}: ${token}`); // Log the JWT token
    res.status(200).json({ token });
    console.log('Login User: Token generated and sent');
  } catch (error) {
    console.error('Error in loginUser:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

/**
 * Login for Admins
 */
const loginAdmin = async (req, res) => {
  const { email, password } = req.body;
  console.log('Login Admin: Received request with data:', req.body);

  try {
    const admin = await Admin.findOne({ email });
    if (!admin) {
      console.log('Login Admin: Invalid credentials for email:', email);
      return res.status(400).json({ message: 'Invalid credentials.' });
    }

    if (!admin.isVerified) {
      return res.status(400).json({ message: 'Please verify your email before logging in.' });
    }

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      console.log('Login Admin: Invalid password for email:', email);
      return res.status(400).json({ message: 'Invalid credentials.' });
    }

    const token = generateToken(admin._id, admin.role);
    console.log(`Login Admin: JWT Token for ${email}: ${token}`); // Log the JWT token
    res.status(200).json({ token });
    console.log('Login Admin: Token generated and sent');
  } catch (error) {
    console.error('Error in loginAdmin:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export default {
  registerUser,
  registerAdmin,
  verifyOTP,
  loginUser,
  loginAdmin,
};
