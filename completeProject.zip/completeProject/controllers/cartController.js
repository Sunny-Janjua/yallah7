import Cart from "../models/cartModel.js";
import Product from "../models/productModel.js";
import { errorHandler } from "../middlewares/authMiddleware.js";

/**
 * Get all items in the user's cart
 */
const getCartItems = async (req, res, next) => {
  try {
    let cart = await Cart.findOne({ user: req.user.id }).populate("items.product", "name price description");

    if (!cart) {
      cart = new Cart({ user: req.user.id, items: [] });
      await cart.save();
    }

    res.status(200).json({ cart });
    console.log(`Get Cart Items: Retrieved cart for user ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in getCartItems:", error);
    next(error);
  }
};

/**
 * Add an item to the user's cart
 */
const addItemToCart = async (req, res, next) => {
  const { productId, quantity } = req.body;

  try {
    if (!productId || !quantity || quantity <= 0) {
      return res.status(400).json({ message: "Valid Product ID and quantity are required." });
    }

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: "Product not found." });
    }

    if (product.stock < quantity) {
      return res.status(400).json({ message: "Insufficient stock for the requested quantity." });
    }

    let cart = await Cart.findOne({ user: req.user.id });

    if (!cart) {
      cart = new Cart({
        user: req.user.id,
        items: [{ product: productId, quantity }],
      });
    } else {
      const existingItemIndex = cart.items.findIndex((item) => item.product.toString() === productId);
      if (existingItemIndex !== -1) {
        cart.items[existingItemIndex].quantity += quantity;
      } else {
        cart.items.push({ product: productId, quantity });
      }
    }

    await cart.save();
    console.log(`Add Item to Cart: Added product ID ${productId} to cart for user ID ${req.user.id}`);
    res.status(200).json({ message: "Item added to cart successfully.", cart });
  } catch (error) {
    console.error("Error in addItemToCart:", error);
    next(error);
  }
};

/**
 * Remove an item from the user's cart by item ID
 */
const removeItemFromCart = async (req, res, next) => {
  const { itemId } = req.params;

  try {
    const cart = await Cart.findOne({ user: req.user.id });

    if (!cart) {
      return res.status(404).json({ message: "Cart not found." });
    }

    const itemIndex = cart.items.findIndex((item) => item._id.toString() === itemId);

    if (itemIndex === -1) {
      return res.status(404).json({ message: "Item not found in cart." });
    }

    cart.items.splice(itemIndex, 1);
    await cart.save();

    res.status(200).json({ message: "Item removed from cart successfully.", cart });
    console.log(`Remove Item from Cart: Removed item ID ${itemId} from cart for user ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in removeItemFromCart:", error);
    next(error);
  }
};

/**
 * Clear all items from the user's cart
 */
const clearCart = async (req, res, next) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id });

    if (!cart) {
      return res.status(404).json({ message: "Cart not found." });
    }

    cart.items = [];
    await cart.save();

    res.status(200).json({ message: "Cart cleared successfully.", cart });
    console.log(`Clear Cart: Cleared cart for user ID ${req.user.id}`);
  } catch (error) {
    console.error("Error in clearCart:", error);
    next(error);
  }
};

// Export all functions
export default {
  getCartItems,
  addItemToCart,
  removeItemFromCart,
  clearCart,
};
