import Seller from "../models/sellerModel.js";
import User from "../models/userModel.js";
import Wallet from "../models/walletModel.js";
import sendEmail from "../utils/emailService.js";
import generateOTP from "../utils/otpGenerator.js";

// Register a new seller
export const registerSeller = async (req, res) => {
  const { userId, storeName, storeDescription } = req.body;

  try {
    console.log("Request body:", req.body); // Log request data

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    if (user.role === "seller") {
      return res.status(400).json({ message: "User is already a seller." });
    }

    // Create a wallet for the seller
    const wallet = new Wallet({ userId: user._id, balance: 0 });
    await wallet.save();
    console.log(`Register Seller: Wallet created for user ID ${userId}`);

    // Create a seller account
    const newSeller = new Seller({
      userId: user._id,
      storeName,
      storeDescription,
      wallet: wallet._id,
    });
    await newSeller.save();
    console.log(`Register Seller: Seller profile created for user ID ${userId}`);

    // Update the user role and link the seller ID and wallet
    user.role = "seller";
    user.sellerId = newSeller._id;
    user.walletId = wallet._id;
    await user.save();
    console.log(`Register Seller: User ID ${userId} updated to seller role`);

    // Optionally, send a welcome email to the seller
    const otp = generateOTP(); // Generate an OTP
    await sendEmail({
      to: user.email,
      subject: "Welcome to the Seller Dashboard!",
      text: `Hello ${user.username}, your seller account has been successfully created. Your OTP is ${otp}.`,
      html: `<p>Hello <b>${user.username}</b>, your seller account has been successfully created. Your OTP is <b>${otp}</b>.</p>`,
    });

    res.status(201).json({ message: "Seller registered successfully.", seller: newSeller });
  } catch (error) {
    console.error("Error in registerSeller:", error);
    res.status(500).json({ message: "Server error.", error: error.message });
  }
};

// Get seller details
export const getSellerDetails = async (req, res) => {
  try {
    const seller = await Seller.findById(req.params.sellerId)
      .populate("products")
      .populate("wallet");

    if (!seller) {
      return res.status(404).json({ message: "Seller not found." });
    }

    res.status(200).json({ seller });
    console.log(`Get Seller Details: Retrieved seller ID ${req.params.sellerId}`);
  } catch (error) {
    console.error("Error in getSellerDetails:", error);
    res.status(500).json({ message: "Server error.", error: error.message });
  }
};

// Update seller profile
export const updateSellerProfile = async (req, res) => {
  const { sellerId } = req.params;
  const { storeName, storeDescription } = req.body;

  try {
    const seller = await Seller.findById(sellerId);
    if (!seller) {
      return res.status(404).json({ message: "Seller not found." });
    }

    // Ensure that the authenticated user is the seller
    if (seller.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to update this seller profile." });
    }

    seller.storeName = storeName || seller.storeName;
    seller.storeDescription = storeDescription || seller.storeDescription;

    await seller.save();
    res.status(200).json({ message: "Seller profile updated successfully.", seller });
    console.log(`Update Seller Profile: Updated seller ID ${sellerId}`);
  } catch (error) {
    console.error("Error in updateSellerProfile:", error);
    res.status(500).json({ message: "Server error.", error: error.message });
  }
};

// Add a product to seller's store
export const addSellerProduct = async (req, res) => {
  const { sellerId, productId } = req.body;

  try {
    const seller = await Seller.findById(sellerId);
    if (!seller) {
      return res.status(404).json({ message: "Seller not found." });
    }

    // Ensure that the authenticated user is the seller
    if (seller.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to add products to this seller." });
    }

    // Add product to seller's product list
    seller.products.push(productId);
    await seller.save();
    console.log(`Add Seller Product: Added product ID ${productId} to seller ID ${sellerId}`);

    res.status(200).json({ message: "Product added to seller.", seller });
  } catch (error) {
    console.error("Error in addSellerProduct:", error);
    res.status(500).json({ message: "Server error.", error: error.message });
  }
};

// Handle wallet transactions for seller (credit or debit)
export const handleSellerTransaction = async (req, res) => {
  const { sellerId, type, amount, description } = req.body;

  try {
    const seller = await Seller.findById(sellerId).populate("wallet");
    if (!seller) {
      return res.status(404).json({ message: "Seller not found." });
    }

    // Ensure that the authenticated user is the seller
    if (seller.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to perform transactions on this seller." });
    }

    const wallet = await Wallet.findById(seller.wallet._id);
    if (!wallet) {
      return res.status(404).json({ message: "Wallet not found." });
    }

    if (type === "credit") {
      wallet.balance += amount;
    } else if (type === "debit") {
      if (wallet.balance < amount) {
        return res.status(400).json({ message: "Insufficient balance." });
      }
      wallet.balance -= amount;
    } else {
      return res.status(400).json({ message: "Invalid transaction type." });
    }

    wallet.transactions.push({
      type,
      amount,
      description,
    });

    wallet.lastUpdated = Date.now();
    await wallet.save();
    console.log(`Handle Seller Transaction: ${type} of ${amount} for seller ID ${sellerId}`);

    res.status(200).json({ message: `Transaction successful: ${type} ${amount}`, wallet });
  } catch (error) {
    console.error("Error in handleSellerTransaction:", error);
    res.status(500).json({ message: "Server error.", error: error.message });
  }
};

// Exporting controller functions
export default {
  registerSeller,
  getSellerDetails,
  updateSellerProfile,
  addSellerProduct,
  handleSellerTransaction,
};
