const validateOTP = (user, providedOTP) => {
  if (!user || !user.otp || !user.otpExpires) {
    return false;
  }

  const isOTPValid = user.otp === providedOTP;
  const isOTPExpired = user.otpExpires < Date.now();

  return isOTPValid && !isOTPExpired;
};

export default validateOTP;
