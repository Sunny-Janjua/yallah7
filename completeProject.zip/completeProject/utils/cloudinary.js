import { v2 as cloudinary } from "cloudinary";
import dotenv from "dotenv";
import fs from "fs/promises"; 

dotenv.config({ path: "./.env" });

// Configure Cloudinary
cloudinary.config({ 
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET
});

export const uploadOnCloudinary = async (localFilePath) => {
    try {
        if (localFilePath) {
            const response = await cloudinary.uploader.upload(localFilePath, {
                folder: "products", // Adjust folder name as needed
                resource_type: "auto",
            });
            await fs.unlink(localFilePath); // Remove the file from local storage after upload
            return response;
        }
    } catch (error) {
        console.error("Error uploading to Cloudinary:", error);
        try {
            if (await fs.stat(localFilePath).catch(() => false)) {
                await fs.unlink(localFilePath); // Remove the file if upload fails
            }
        } catch (fsError) {
            console.error("Error removing local file:", fsError);
        }
        return null;
    }
};
